// 지울 파일과 폴더를 휴지통으로 보낸다: node ~/.claude/trash.mjs <경로> [<경로> ...]
import { existsSync, renameSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { basename, join, resolve } from "node:path";
import { homedir } from "node:os";

const paths = process.argv.slice(2).map((p) => resolve(p));
if (!paths.length) {
  console.error("사용법: node trash.mjs <경로> [<경로> ...]");
  process.exit(1);
}

const ps = `Add-Type -AssemblyName Microsoft.VisualBasic
$fs = [Microsoft.VisualBasic.FileIO.FileSystem]
foreach ($p in ($env:TRASH_PATHS -split "\`n")) {
  if (Test-Path -LiteralPath $p -PathType Container) { $fs::DeleteDirectory($p, 'OnlyErrorDialogs', 'SendToRecycleBin') }
  else { $fs::DeleteFile($p, 'OnlyErrorDialogs', 'SendToRecycleBin') }
}`;

let failed = 0;
const missing = paths.filter((p) => !existsSync(p));
for (const p of missing) console.error(`없음: ${p}`);
const found = paths.filter((p) => existsSync(p));

if (found.length && process.platform === "win32") {
  const r = spawnSync("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", ps], {
    env: { ...process.env, TRASH_PATHS: found.join("\n") },
    stdio: "inherit",
  });
  if (r.status !== 0) failed = 1;
} else {
  for (const p of found) {
    let to = join(homedir(), ".Trash", basename(p));
    if (existsSync(to)) to += ` ${Date.now()}`;
    renameSync(p, to);
  }
}

for (const p of found) if (!existsSync(p)) console.log(`휴지통으로: ${p}`);
process.exit(failed || missing.length ? 1 : 0);
