import json, sys

sys.stdout.reconfigure(encoding="utf-8")
d = json.load(sys.stdin)

cw = d.get("context_window") or {}
tok = cw.get("total_input_tokens") or 0
pct = int(cw.get("used_percentage") or 0)
k = tok // 1000

model = ((d.get("model") or {}).get("display_name") or "?")
model = model.replace("1M context", "1M").replace(" ", "")
eff = (d.get("effort") or {}).get("level")
tail = f"{model}/{eff}" if eff else model

rl = d.get("rate_limits") or {}
sess = (rl.get("five_hour") or {}).get("used_percentage")
if sess is not None:
    tail += f" · sess {int(sess)}%"
wk = (rl.get("seven_day") or {}).get("used_percentage")
if wk is not None:
    tail += f" · wk {int(wk)}%"

filled = min(pct // 5, 20)
empty = 20 - filled

# muted zones: green → amber decision band (10-25%) → orange → deep red
if pct < 10:
    code = 108
elif pct < 25:
    code = 137
elif pct < 50:
    code = 130
else:
    code = 88
c = f"\033[38;5;{code}m"
r, dim = "\033[0m", "\033[2m"

print(f"ctx {k}k {c}{'█'*filled}{r}{dim}{'░'*empty}{r} {pct}%  {dim}{tail}{r}")
