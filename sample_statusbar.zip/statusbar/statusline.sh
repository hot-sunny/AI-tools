#!/bin/bash
input=$(cat)
read -r tok pct < <(printf '%s' "$input" | jq -r '"\(.context_window.total_input_tokens // 0) \((.context_window.used_percentage // 0)|floor)"')
k=$((tok/1000))

model=$(printf '%s' "$input" | jq -r '.model.display_name // "?"')
model=${model//1M context/1M}
model=${model// /}
eff=$(printf '%s' "$input" | jq -r '.effort.level // empty')
[ -n "$eff" ] && tail="$model/$eff" || tail="$model"

sess=$(printf '%s' "$input" | jq -r '(.rate_limits.five_hour.used_percentage // empty)|floor')
[ -n "$sess" ] && tail="$tail · sess ${sess}%"

wk=$(printf '%s' "$input" | jq -r '(.rate_limits.seven_day.used_percentage // empty)|floor')
[ -n "$wk" ] && tail="$tail · wk ${wk}%"

filled=$((pct/5))
[ "$filled" -gt 20 ] && filled=20
empty=$((20-filled))

# muted zones: green → amber decision band (10-25%) → orange → deep red
if   [ "$pct" -lt 10 ]; then code=108   # muted green
elif [ "$pct" -lt 25 ]; then code=137   # amber — 결정존
elif [ "$pct" -lt 50 ]; then code=130   # muted orange
else                        code=88     # deep red
fi
c=$'\033[38;5;'"$code"'m'
r=$'\033[0m'; d=$'\033[2m'

bar=""; for ((i=0;i<filled;i++)); do bar+="█"; done
gap=""; for ((i=0;i<empty;i++)); do gap+="░"; done

printf 'ctx %dk %s%s%s%s%s %d%%  %s%s%s\n' "$k" "$c" "$bar" "$r$d" "$gap" "$r" "$pct" "$d" "$tail" "$r"
